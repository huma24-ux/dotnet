﻿using Microsoft.AspNetCore.Mvc;
using projectmini.Data;
using projectmini.Models;

namespace projectmini.Controllers
{

    public class AdminController : Controller
    {

        private readonly MyContext _context;   // class variable
        private IWebHostEnvironment _env;

        public AdminController(MyContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;

        }
        public IActionResult Index()
        {
            var faculties = _context.Faculties.ToList();
            return View(faculties);
        }



        public IActionResult CreateFaculty()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreateFaculty(Faculty f, IFormFile image)
        {
            // get logged-in user id from session
            string userid = HttpContext.Session.GetString("user_id");

            if (userid == null)
                return RedirectToAction("Login");

            f.UserId = Convert.ToInt32(userid);   //  IMPORTANT LINE

            string fileExtension = Path.GetExtension(image.FileName).ToLower();   // .jpg  .png  .jfif  .webp

            // validation for file extension
            if (fileExtension == ".jpg" || fileExtension == ".png" || fileExtension == ".jfif")
            {

                string imagePath = Path.Combine(_env.WebRootPath, "admin", "images", "faculty", image.FileName);

                using (FileStream fs = new FileStream(imagePath, FileMode.Create))
                {
                    image.CopyTo(fs);
                }

                f.Image = image.FileName; // property in Faculty model

                _context.Faculties.Add(f);
                _context.SaveChanges();


                ViewBag.message = "File uploaded successfully";    // on success message
            }

            else
            {
                ViewBag.message = "Only JPG or PNG allowed";   // on failure message
            }

            return RedirectToAction("Index");
        }


        public IActionResult UpdateFaculty(int id)
        {
            var faculty = _context.Faculties.Find(id);
            if (faculty == null)
                return NotFound();

            return View(faculty);
        }
        [HttpPost]
        public IActionResult UpdateFaculty(Faculty f, IFormFile image)
        {
            var faculty = _context.Faculties.Find(f.FacultyId);
            if (faculty == null)
                return NotFound();

            faculty.Name = f.Name;
            faculty.Email = f.Email;
            faculty.Experience = f.Experience;
            faculty.Department = f.Department;

            if (image != null)
            {
                string path = Path.Combine(_env.WebRootPath,
                    "admin", "images", "faculty", image.FileName);

                using var fs = new FileStream(path, FileMode.Create);
                image.CopyTo(fs);

                faculty.Image = image.FileName;
            }

            _context.SaveChanges();
            return RedirectToAction("Index");
        }


        public IActionResult DeleteFaculty(int id)
        {
            var faculty = _context.Faculties.Find(id);

            if (faculty == null)
                return NotFound();

            _context.Faculties.Remove(faculty);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }


    }
}
